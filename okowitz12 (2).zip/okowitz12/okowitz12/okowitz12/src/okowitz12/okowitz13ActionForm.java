package okowitz12;

import org.apache.struts.action.*;

public class okowitz13ActionForm extends ActionForm  {

    



    public okowitz13ActionForm() {
    }
}
